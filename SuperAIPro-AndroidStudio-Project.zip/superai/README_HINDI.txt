SUPER AI PRO - Android project

IMPORTANT:
- Is ZIP mein Android Studio project source hai, compiled APK nahi.
- Is environment mein Android SDK/Gradle build setup nahi mila, isliye main APK compile karke verify nahi kar saka.
- App ke Chat/Fun/Deep modes third-party Pollinations text service ko call karte hain. Ye official ChatGPT Plus ya official Grok access nahi hai; unke paid models/subscription is app mein included nahi hain.
- Image/video mode third-party image service par depend karta hai. Video mode asli AI video generation nahi, balki do generated images ka simple motion effect record karta hai.
- Internet required hai. Third-party service ki availability, limits aur privacy policies badal sakti hain. Sensitive/private data mat bhejein.

BUILD ON PC:
1. ZIP extract karein.
2. Android Studio mein extracted 'superai' folder Open karein.
3. Android SDK Platform 35 install/accept karein agar prompt aaye.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/app-debug.apk par milega.

BUILD USING GITHUB ACTIONS:
1. ZIP extract karke files ko ek GitHub repository mein upload karein (root par settings.gradle hona chahiye).
2. Repository ke Actions tab mein 'Build Super AI Pro APK' workflow kholein.
3. Run workflow dabayein.
4. Build successful hone par run ke Artifacts section se 'SuperAIPro-debug-apk' download karein; ZIP ke andar app-debug.apk hoga.
